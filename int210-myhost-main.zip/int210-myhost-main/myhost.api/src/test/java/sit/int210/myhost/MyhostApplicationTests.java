package sit.int210.myhost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyhostApplicationTests {

	@Test
	void contextLoads() {
	}

}
